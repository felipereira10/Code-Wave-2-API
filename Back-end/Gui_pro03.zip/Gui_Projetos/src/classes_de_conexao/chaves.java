package com.codewave;

public class chaves {
        public static String chave_api = "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";
}