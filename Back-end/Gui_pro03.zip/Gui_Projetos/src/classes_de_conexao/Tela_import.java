package classes_de_conexao;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Tela_import extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tela_import frame = new Tela_import();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Tela_import() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 454, 307);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnImport = new JButton("IMPORT");
		btnImport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			
				
				
				
				
			
			
			}
		});
		btnImport.setForeground(new Color(255, 255, 255));
		btnImport.setBackground(new Color(128, 128, 128));
		btnImport.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnImport.setBounds(24, 85, 117, 29);
		contentPane.add(btnImport);
		
		JButton btnRecords = new JButton("RECORDS");
		btnRecords.setForeground(new Color(255, 255, 255));
		btnRecords.setBackground(new Color(128, 128, 128));
		btnRecords.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnRecords.setBounds(24, 145, 117, 29);
		contentPane.add(btnRecords);
		
		JLabel lblImport = new JLabel("IMPORT YOUR FILE");
		lblImport.setForeground(new Color(255, 255, 255));
		lblImport.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblImport.setBounds(143, 11, 168, 35);
		contentPane.add(lblImport);
		
		JTextPane textPane = new JTextPane();
		textPane.setFont(new Font("Tahoma", Font.BOLD, 16));
		textPane.setBounds(151, 85, 160, 29);
		contentPane.add(textPane);
		
		JButton btnNewButton = new JButton("EXIT");
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(128, 128, 128));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			Tela_import.this.dispose(); 
			
			Tela_login frame = new Tela_login();
			frame.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(345, 235, 89, 26);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("SEARCH");
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setBackground(new Color(128, 128, 128));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_1.setBounds(321, 85, 107, 28);
		contentPane.add(btnNewButton_1);
	}
}
